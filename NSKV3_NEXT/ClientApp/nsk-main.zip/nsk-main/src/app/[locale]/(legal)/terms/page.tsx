import Content from "./content.mdx";

export default function TermsPage() {
  return (
    <article className="prose pb-8 dark:prose-invert lg:prose-xl">
      <Content />
    </article>
  );
}
