export default function PreferencesPage() {
  return (
    <div>
      <h1>Preferences</h1>
      <p>Under construction...</p>
    </div>
  );
}
