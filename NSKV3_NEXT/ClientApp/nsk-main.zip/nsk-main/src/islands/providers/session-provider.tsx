"use client";

import { SessionProvider as NextAuthProvider } from "next-auth/react";

/** @see https://github.com/jherr/app-router-auth-using-next-auth */

export default NextAuthProvider;
