export default function Calculator() {
  return (
    <section>
      <iframe
        className="w-full h-[1530px]"
        src="https://online.nsk.kz/design/?csrf=sBzU87Eua0DCZ7rNZwqlys81xmP6quEIh8Qk7vW3djv2JIKl_Ro0Ja5f4rc2UsyThwaUDcndtmTkglaeheJETg==&host=https://www.nsk.kz&promo=0&lang=ru"
      />
    </section>
  );
}
