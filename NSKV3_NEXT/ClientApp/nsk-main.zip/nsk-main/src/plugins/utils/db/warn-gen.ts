console.log("💡 Please use `pnpm mysql:generate` or `pnpm pg:generate`");
process.exit(0); // Ensures script exits without additional output
