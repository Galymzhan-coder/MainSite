console.log("💡 Please use `pnpm mysql:push` or `pnpm pg:push`");
process.exit(0); // Ensures script exits without additional output
